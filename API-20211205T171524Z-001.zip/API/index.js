import * as users from "./fake.api/user.api"
const API = {
    users
}
export default API